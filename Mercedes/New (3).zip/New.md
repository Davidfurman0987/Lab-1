﻿\# Mercedes Dealership — One Page Website

Односторінковий сайт для лабораторної роботи №1.

\## Функціонал

\- Меню з навігацією

\- Головний банер

\- Каталог авто Mercedes

\- Галерея

\- Форма опитування

\- Форма авторизації

\## Як запустити на GitHub Pages

1\. Створи репозиторій

2\. Завантаж усі файли

3\. Перейди у Settings → Pages

4\. Обери "Deploy from branch"

5\. Branch = main, folder = root

6\. Зберегти

Сайт відкриється за адресою:

https://username.github.io/repository-name/
